def simple_interest(principal, rate, time):
    return (principal * rate * time) / 100

def compound_interest(principal, rate, time):
    return principal * (1 + rate / 100) ** time - principal


def simple_interest(principal, rate, time):
    try:
        principal = float(principal)
        rate = float(rate)
        time = float(time)
        if principal < 0 or rate < 0 or time < 0:
            return "Error: Please enter positive values."
        interest = (principal * rate * time) / 100
        return interest
    except ValueError:
        return "Error: Please enter numbers for principal, rate, and time."