def calculate_net_income(revenue, expenses):
    return revenue - expenses
    

def calculate_net_income(revenue, expenses):
    net_income = revenue - expenses
    if revenue > 5000:
        net_income -= net_income * 0.1
    return net_income
